#include "IntList.h"

bool IntList::bubbleUp() {
   return false;
}

bool IntList::bubbleUp(IntNode *curr) {
   return false;
}
