#include "BSTree.h"
#include "Node.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

// Constructors
BSTree::BSTree() { root = nullptr; }

// TODO  Finish this boy
BSTree::BSTree(const BSTree &cpy) { root = cpy.root; }

BSTree::BSTree(Node *insRoot) { root = insRoot; }
BSTree::~BSTree() { delete root; } // Gives less errors
/* BSTree::~BSTree() { clear(); } */

// FIX  May depricate
void BSTree::clear() {
  clear(root);
  root = nullptr;
}

// FIX  May depricate
void BSTree::clear(Node *curr) {
  if (curr) {
    clear(curr->getLeft());
    clear(curr->getRight());
    delete curr;
  }
}

// Printing tree using recursive helper functions
void BSTree::preOrder() const { preOrder(root); }
void BSTree::inOrder() const { inOrder(root); }
void BSTree::postOrder() const { postOrder(root); }

// manipulators

void BSTree::insert(const string &data) { root = insert(root, data); }

Node *BSTree::insert(Node *root, const string &data) {
  if (root == nullptr) {
    return new Node(data); // if root, just add new node
  }

  if (data == root->getData()) {
    root->incrementCount(); // updating counter if dupe
  } else if (data < root->getData()) {
    root->setLeft(insert(root->getLeft(), data));
  } else {
    root->setRight(insert(root->getRight(), data));
  }

  return root;
}

// FIX  Depricate this whole fucntion
/* void BSTree::insert(const string &data) {
  Node *inNode = new Node(data);

  // If empty BST, terminates once job is done
  if (!root) {
    root = inNode;
    return;
  }

  Node *curr = root;

  // Loop interates through the tree
  // to see where the new node to the prefered placement
  while (curr) {
    if (inNode->getData() == curr->getData()) { // if dupe is found
      curr->setCount(curr->getCount() + 1);
      return;
    }

    // if left(or right) is null
    // Insert the new node there
    if (inNode->getData() < curr->getData()) { // Left of head
      if (!curr->getLeft()) {
        curr->setLeft(inNode); // If there is no left child, insert!
        return;
      } else {
        curr = curr->getLeft();
      }
    } else {
      if (inNode->getData() > curr->getData()) { // right of head
        if (!curr->getRight()) {
          curr->setRight(inNode); // If there is a no right child, insert!
          return;
        } else {
          curr = curr->getRight(); // scoop right
        }
      }
    }
  }
} */

bool BSTree::search(const string &target) const {
  Node *curr = root;
  if (!curr) {
    return false;
  }

  // BST, left for smaller
  // Right for bigger
  // Keeps going until it is found, or leaf found is found
  while (curr != nullptr && !(curr->getData() == target)) {
    if (curr->getData() < target) {
      curr = curr->getRight();
    } else if (curr->getData() > target) {
      curr = curr->getLeft();
    }
  }

  // If target is found, curr is !nullptr
  if (curr != nullptr)
    return true;
  else
    return false; // if curr is nullptr, then return false
}

string BSTree::largest() const {

  // If root is a nullptr, then BST is empty
  if (isEmpty()) {
    /* throw runtime_error("Empty BST, largest"); */
    return "";
  }

  Node *curr = root;

  // If tree only has a root
  if (!curr->getLeft() && !curr->getRight()) {
    return curr->getData();
  }

  // Traverse to the rightmost leaf
  while (curr->getRight()) {
    curr = curr->getRight();
  }
  return curr->getData();
}

string BSTree::smallest() const {

  if (isEmpty()) {
    /* throw runtime_error("Empty BST, smallest"); */
    return "";
  }

  Node *curr = root;

  // If tree only has a root
  if (!curr->getLeft() && !curr->getRight()) {
    return curr->getData();
  }

  // Traverse to leftmost leaf
  while (curr->getLeft()) {
    curr = curr->getLeft();
  }
  return curr->getData();
}

/* int BSTree::height(const string &data) const { return height(root, data); }
 */

// NOTE  Best Working height
int BSTree::height(const string &data) const {
  if (!search(data)) {
    return -1;
  }

  Node *curr = root;
  while (curr != nullptr && !(curr->getData() == data)) {
    if (curr->getData() < data) {
      curr = curr->getRight();
    } else if (curr->getData() > data) {
      curr = curr->getLeft();
    }
  }

  Node *currLeft = curr;
  Node *currRight = curr;
  int countRight = 0;
  int countLeft = 0;

  // Logic required to iterate through tree
  if (curr->getLeft() != nullptr) {
    currLeft = currLeft->getLeft();
    countLeft++;
    countLeft = countLeft + height(currLeft->getData());
  }
  if (curr->getRight() != nullptr) {
    currRight = currRight->getRight();
    countRight++;
    countRight = countRight + height(currRight->getData());
  }

  // Returns the larger value, post recursive
  return std::max(countLeft, countRight);
}

// TESTING   BETA
/* int BSTree::height(const string &data) const { return height(root, data); }
 */
int BSTree::height(Node *root, const string &data) const {
  if (!search(data)) {
    return -1;
  }

  if (data == root->getData()) {
    // if node found, calc height
    int LHeight = height(root->getLeft(), data);
    int RHeight = height(root->getRight(), data);
    return 1 + std::max(LHeight, RHeight);
  } else if (data < root->getData()) {
    return height(root->getLeft(), data);
  } else {
    return height(root->getRight(), data);
  }
}

// Printing private helper
// TODO
// Visit root
// Traverse left subtree
// Traverse right subtree
void BSTree::preOrder(Node *curr) const {
  if (curr) {
    cout << curr->getData() << '(' << curr->getCount() << "), ";
    preOrder(curr->getLeft());
    preOrder(curr->getRight());
  }
}

// Traverse left subtree
// visit root
// traverse the right subtree
void BSTree::inOrder(Node *curr) const {
  if (curr) {
    inOrder(curr->getLeft());
    cout << curr->getData() << '(' << curr->getCount() << "), ";
    inOrder(curr->getRight());
  }
}

// Traverse left subtree
// Traverse right subtree
// visit root
void BSTree::postOrder(Node *curr) const {
  if (curr) {
    postOrder(curr->getLeft());
    postOrder(curr->getRight());
    cout << curr->getData() << '(' << curr->getCount() << "), ";
  }
}

// Left-most leaf is the smallest value
Node *BSTree::min(Node *curr) const {
  // Keeps going left until leaf is found
  while (curr->getLeft()) {
    curr = curr->getLeft();
  }
  return curr;
}

// Right-most leaf is the largest value
Node *BSTree::max(Node *curr) const {
  // Keeps going right until leaf is found
  while (curr->getRight()) {
    curr = curr->getRight();
  }
  return curr;
}

void BSTree::remove(const string &data) {
  /* if (isEmpty()) { // Already checks if it is empty
    throw runtime_error("BST is empty");
    return;
  } */
  remove(nullptr, root, data);
}

void BSTree::remove(Node *prev, Node *curr, string data) {
  if (curr == nullptr) {
    return;
  } else if (curr->getData() ==
             data) { // If current node contains our target data
    // NOTE  If leaf node (null right and left)
    if (!curr->getLeft() && !curr->getRight()) {
      if (prev) {
        // update parent to null
        if (prev->getLeft() == curr) {
          prev->setLeft(nullptr);
        } else {
          prev->setRight(nullptr);
        }
        delete curr;
      } else {
        // Node is root
        delete root;
        root = nullptr;
      }
    }

    // NOTE  Node with one child

    // if only has a right child
    else if (!curr->getLeft()) {
      // Update where node only has a right child
      updateParentLink(prev, curr, curr->getRight());
      delete curr;
    }

    // Only has a left child
    else if (!curr->getRight()) {
      updateParentLink(prev, curr, curr->getLeft());
      delete curr;
    }

    // NOTE  Node has two children
    else {
      Node *sucessor = min(curr->getRight());
      curr->setData(sucessor->getData());
      remove(curr, curr->getRight(), sucessor->getData());
    }
  } else if (curr->getData() < data) { // These two statements run
    remove(curr, curr->getRight(), data);
  } else {
    remove(curr, curr->getLeft(), data);
  }
}

// Helps bring down complexity in Remove
void BSTree::updateParentLink(Node *prev, Node *curr, Node *child) {
  if (prev) {
    // Updates parent's pointer to child
    if (prev->getLeft() == curr) {
      prev->setLeft(child);
    } else {
      prev->setRight(child);
    }
  } else {
    // Node is root
    root = child;
  }
}

bool BSTree::isEmpty() const { return !root; }
