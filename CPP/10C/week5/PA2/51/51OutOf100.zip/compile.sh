#!/bin/bash
g++ Node.cpp main.cpp BSTree.cpp -Wall -Werror -Wuninitialized -o a.out
